Test Reference Sequence 1m
==========================

This is the first ~1 Mbps of human chromosome 7 with all N's removed as well#
as a modified version with several artifical gaps and repeats as listed below.

Modifications
-------------

1. 8301-12400 (ll 168-249): gap of length 4100
2. 20751-29200 (ll 417-585): gap of length 8450
3. 37551-40000 (ll 753-801): mini satellite with 50 repeats of length 50
4. LINE repeat with gap after last repeat
	1. 49901-54900 (ll 1000-1099): LINE1 (original sequence)
	2. 74901-79900 (ll 1500-1599): copy of LINE1
	3. 99901-104900 (ll 2000-2099): copy of LINE1
	4. 149901-154900 (ll 3000-3099): copy of LINE1
	5. 154901-159900 (ll 3100-3199): gap of length 5000
5. gap with bad reference quality before and after
	1. 168651-169900 (ll 3375-3399): errors with rate 15% of length 1250
	2. 169901-174900 (ll 3400-3499): gap of length 5000
	3. 174901-176150 (ll 3500-3524): errors with rate 15% of length 1250

```
╭─╴contig 1 #8300╶─╮             ╭─╴contig 2 #8350╶─╮             ╭─────────┄┄
--------------------[ #4100 (1) ]--------------------[ #8450 (2) ]------------

┄┄─────────────────╴contig 3 #125700╶───────────────────╮               ╭───┄┄
--~~(3)~~---~~(4.1)~~---~~(4.2)~~---~~(4.3)~~---~~(4.4)~~[ #5000 (4.5) ]------

┄┄╴contig 4 #10000╶─╮               ╭─╴contig 5 #662650╶─┄┄
-----------~~~(5.1)~~[ #5000 (5.2) ]~~(5.3)~~--------------
```
