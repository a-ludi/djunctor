#!/bin/bash

set -e  # Exit immediately if a command exits with a non-zero status.
set -x  # Print commands and their arguments as they are executed.

INPUT="${1:-reference}"
OUTPUT="${2:-reads}"

DMrm -v "$OUTPUT"
simulator "$INPUT" -e.025 > "$OUTPUT.fasta"
fasta2DAM "$OUTPUT.dam" "$OUTPUT.fasta"
DBsplit "$OUTPUT.dam"
du -sch "$OUTPUT."{fasta,dam} ".$OUTPUT."{bps,hdr,idx}
